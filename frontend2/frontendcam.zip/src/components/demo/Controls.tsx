import { Button } from "@/components/ui/button";
import { Undo, Delete, Volume2, RotateCcw, Check, ChevronLeft, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";

interface ControlsProps {
  onAccept: () => void;
  onPrev: () => void;
  onNext: () => void;
  onUndo: () => void;
  onBackspace: () => void;
  onSpace: () => void;
  onFinalize: () => void;
  onReset: () => void;
  canAccept: boolean;
  hasPrev: boolean;
  hasNext: boolean;
  canUndo: boolean;
  text: string;
  locked: boolean;
}

export const Controls = ({
  onAccept,
  onPrev,
  onNext,
  onUndo,
  onBackspace,
  onSpace,
  onFinalize,
  onReset,
  canAccept,
  hasPrev,
  hasNext,
  canUndo,
  text,
  locked,
}: ControlsProps) => {
  return (
    <Card className="p-6 bg-muted/30">
      <div className="space-y-3">
        <h3 className="font-semibold mb-3">Controls</h3>
        
        {/* Accept Button - Primary Action */}
        <Button
          onClick={onAccept}
          disabled={!canAccept || locked}
          className="w-full bg-gradient-to-r from-primary to-primary-glow hover:opacity-90"
          size="lg"
        >
          <Check className="h-5 w-5 mr-2" />
          Accept Letter
        </Button>

        {/* Navigation: Prev/Next */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={onPrev}
            disabled={!hasPrev || locked}
            variant="secondary"
            size="lg"
            className="w-full"
          >
            <ChevronLeft className="h-5 w-5 mr-2" />
            Prev
          </Button>
          <Button
            onClick={onNext}
            disabled={!hasNext || locked}
            variant="secondary"
            size="lg"
            className="w-full"
          >
            Next
            <ChevronRight className="h-5 w-5 ml-2" />
          </Button>
        </div>

        {/* Text Editing */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={onSpace}
            variant="secondary"
            size="lg"
            className="w-full"
          >
            Space
          </Button>
          
          <Button
            onClick={onBackspace}
            variant="secondary"
            size="lg"
            className="w-full"
            disabled={text.length === 0}
          >
            <Delete className="h-5 w-5 mr-2" />
            Backspace
          </Button>
          
          <Button
            onClick={onUndo}
            variant="secondary"
            size="lg"
            className="w-full"
            disabled={!canUndo}
          >
            <Undo className="h-5 w-5 mr-2" />
            Undo
          </Button>
          
          <Button
            onClick={onReset}
            variant="secondary"
            size="lg"
            className="w-full"
          >
            <RotateCcw className="h-5 w-5 mr-2" />
            Reset
          </Button>
        </div>

        {/* Speak Button */}
        <Button
          onClick={onFinalize}
          disabled={text.trim().length === 0}
          className="w-full bg-gradient-to-r from-accent to-primary hover:opacity-90"
          size="lg"
        >
          <Volume2 className="h-5 w-5 mr-2" />
          Speak Text
        </Button>
      </div>
    </Card>
  );
};
