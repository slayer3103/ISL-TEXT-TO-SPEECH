// src/lib/suggestions/suggestionEngine.ts
import type { Trie } from "../trie/trie";

/**
 * SuggestionEngine - thin adapter around Trie that returns plain string[] for the UI.
 *
 * Methods:
 *  - getTopCompletions(prefix, limit, opts) => { word, freq }[]  (delegates to Trie.getTopCompletions)
 *  - getTopSuggestions(prefix, distMap, limit) => string[]       (plain strings for UI)
 *
 * Notes:
 *  - prefix is lower-cased for Trie lookups (your Trie stores lowercase words).
 *  - distMap is an object like { "a": 0.92, "b": 0.03 } representing model char predictions.
 *  - This intentionally excludes single-letter completions by default (controlled in Trie options).
 */

export type DistMap = { [token: string]: number };

export class SuggestionEngine {
  trie: Trie;

  constructor(trieInstance: Trie) {
    this.trie = trieInstance as any;
  }

  /**
   * Directly expose the trie's top completions (keeps freq)
   */
  getTopCompletions(prefix: string, limit = 5, opts?: { minLen?: number; maxLen?: number; requireVowel?: boolean }) {
    const p = String(prefix || "").toLowerCase();
    // delegate to Trie.getTopCompletions which returns {word,freq}[]
    // ensure we pass sensible defaults: exclude 1-letter completions by default
    return (this.trie.getTopCompletions(p, limit, opts || { minLen: 2 })) || [];
  }

  /**
   * Return plain string[] for the UI (best-effort).
   *
   * Strategy:
   * 1. If prefix supplied -> return completions for that prefix.
   * 2. If no prefix but distMap exists (model predicted chars), use the top characters
   *    to seed prefix searches (e.g., suggestions for words starting with predicted letter).
   * 3. De-duplicate and trim to `limit`.
   */
  getTopSuggestions(prefix: string, distMap?: DistMap, limit = 5): string[] {
    const p = String(prefix || "").toLowerCase().trim();
    const results: string[] = [];
    const seen = new Set<string>();

    const pushWords = (arr: Array<{ word: string; freq?: number }>) => {
      for (const r of arr) {
        if (!r || !r.word) continue;
        const w = String(r.word).toLowerCase();
        if (seen.has(w)) continue;
        seen.add(w);
        results.push(w);
        if (results.length >= limit) break;
      }
    };

    // 1) If user has typed a prefix -> use it directly
    if (p.length > 0) {
      const tops = this.getTopCompletions(p, limit, { minLen: 2 });
      pushWords(tops);
      return results;
    }

    // 2) No prefix: use distMap (character distribution) to seed completions
    if (distMap && Object.keys(distMap).length > 0) {
      // build sorted list of tokens from distMap (descending by confidence)
      const tokens = Object.keys(distMap)
        .map(k => ({ k: String(k || "").toLowerCase(), v: Number(distMap[k] || 0) }))
        .filter(x => x.k.length > 0)
        .sort((a, b) => b.v - a.v);

      // Try top N predicted leading tokens and collect completions from each
      const TOP_TOKENS = Math.min(4, tokens.length);
      const perTokenLimit = Math.max(3, Math.ceil(limit / Math.max(1, TOP_TOKENS)));

      for (let i = 0; i < TOP_TOKENS && results.length < limit; ++i) {
        const tok = tokens[i].k;
        // Prefer single-char tokens (like predicted letter) as prefix for words
        const pref = tok.length === 1 ? tok : tok;
        const completions = this.getTopCompletions(pref, perTokenLimit, { minLen: 2 });
        pushWords(completions);
      }

      // If still empty, fall back to most frequent completions for "a" .. "z"
      if (results.length === 0) {
        const fallback = this.getTopCompletions("", limit, { minLen: 3 });
        pushWords(fallback);
      }

      return results.slice(0, limit);
    }

    // 3) No prefix & no distMap: fallback to most common words
    const fallback = this.getTopCompletions("", limit, { minLen: 3 });
    pushWords(fallback);

    return results.slice(0, limit);
  }
}

export default SuggestionEngine;
